This zip file contains a number of materials related to the dataset you downloaded. These include:

* README.txt: This file.
* 2016_ucr_drug_arrest.csv: Illinois Uniform Crime Reports (I-UCR) Drug Arrests data in the comman-separated value format
* metadata_2016_ucr_drug_arrest.txt: Detailed information about 2016_ucr_drug_arrest.csv

This dataset is prepared and published by Illinois Criminal Justice Information Authority (ICJIA). Visit http://icjia.state.il.us to learn more about ICJIA.
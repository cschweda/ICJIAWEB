This zip file contains a number of materials related to the dataset you downloaded. These include:

* README.txt: This file.
* 2016_ucr_index_arrest.csv: Illinois Uniform Crime Reports (I-UCR) Index Arrests data in the comman-separated value format
* metadata_2016_ucr_index_arrest.txt: Detailed information about 2016_ucr_index_arrest.csv
* 2016_ucr_index_offense.csv: Illinois Uniform Crime Reports (I-UCR) Index Offenses data in the comman-separated value format
* metadata_2016_ucr_index_offense.txt: Detailed information about 2016_ucr_index_offense.csv

This dataset is prepared and published by Illinois Criminal Justice Information Authority (ICJIA). Visit http://icjia.state.il.us to learn more about ICJIA.